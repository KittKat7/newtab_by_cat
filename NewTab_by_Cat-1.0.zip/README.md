# New Tab<sub>by</sub> Cat

A very cat themed new tab page for chromium based browsers.